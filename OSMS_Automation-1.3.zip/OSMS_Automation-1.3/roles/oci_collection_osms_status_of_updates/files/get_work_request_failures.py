#!/usr/bin/python3
import oci
import sys
import getopt

def main(argv):
    profile = 'DEFAULT'
    work_request_id = None
    region=None
    try:
      opts, args = getopt.getopt(argv,"p:wid:r:",["profile=","work_request_id=", "region="])
    except getopt.GetoptError:
        print('get_work_request_status.py -profile <profile_name> -wid <work_request_ocid>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print('get_work_request_status.py -profile <profile_name> -wid <work_request_ocid>')
            sys.exit()
        elif opt in ("-p", "--profile"):
            profile = arg
        elif opt in ("-wid", "--work_request_id"):
            work_request_id = arg
        elif opt in ("-r", "--region"):
            region = arg
    # Get the OCI Config
    config = oci.config.from_file(profile_name=profile, file_location="./.oci/config")
    if region != None:
        config["region"] = region

    # Initialize service client with config
    os_management_client = oci.os_management.OsManagementClient(config)

    # Send the request to service and retrieve work request info
    get_work_request_response = os_management_client.list_work_request_errors(work_request_id=work_request_id)

    # Get the data from response
    print(get_work_request_response.data)


if __name__ == "__main__":
   main(sys.argv[1:])